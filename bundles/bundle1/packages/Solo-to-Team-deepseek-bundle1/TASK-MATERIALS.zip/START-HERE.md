# 本单任务资料

先读 [开工读取指引](开工读取指引.md)，再按任务读 [基础Skills](foundation/README.md)。本附件不执行安装。采用平台Skill的步骤在完整下载包的START-HERE.md；本附件仅提供本单获准的资料。版本与文件清单见 MATERIALS.json。
