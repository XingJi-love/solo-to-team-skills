#!/usr/bin/env python3
"""Package locked Grok body and task materials; never install or contact a host."""
import argparse
import hashlib
import io
import json
import stat
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fingerprint(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def checked_path(name):
    path = PurePosixPath(name)
    require(name == path.as_posix() and not path.is_absolute()
            and '..' not in path.parts and '\\' not in name, 'Unsafe member name')
    return path


def read_locked(path, expected):
    require(path.is_file() and not path.is_symlink(), 'Missing or symlinked input')
    data = path.read_bytes()
    require(fingerprint(data) == expected, 'Input identity differs: ' + path.name)
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    require(not output.exists(), 'Use a new output directory; old results are preserved')
    source_manifest = json.loads((ROOT / 'source-manifest.json').read_text('utf-8'))
    for name, expected in source_manifest['files'].items():
        checked_path(name)
        read_locked(ROOT / name, expected)
    lock = json.loads((ROOT / 'input-lock.json').read_text('utf-8'))
    require(lock['candidate_id'] == 'grok-task-materials-design-2-doc-1', 'Wrong candidate')
    require(lock['skill_release_version'] is None, 'Do not invent a Skill release version')
    require(lock['delivery_status'] == 'pending_integration_candidate_not_formally_accepted',
            'This builder is scoped to the pending candidate')
    expected_names = {'body.md', 'task-materials/manifest.json', 'task-materials/LICENSE',
                      'task-materials/references/group-config.md',
                      'task-materials/references/groups.zh.md',
                      'task-materials/references/role-routing.md',
                      'task-materials/references/roles.zh.md'}
    require(set(lock['payload_files']) == expected_names, 'Unexpected payload contract')
    actual_names = {p.relative_to(ROOT / 'payload').as_posix()
                    for p in (ROOT / 'payload').rglob('*') if p.is_file()}
    require(actual_names == expected_names, 'Unexpected source payload')
    files = {}
    for name, expected in lock['payload_files'].items():
        checked_path(name)
        files[name] = read_locked(ROOT / 'payload' / name, expected)
    task_manifest = json.loads(files['task-materials/manifest.json'])
    require(task_manifest['candidate_id'] == lock['candidate_id'], 'Task candidate differs')
    require(task_manifest['expected_body'] == fingerprint(files['body.md']), 'Body binding differs')
    for name, expected in task_manifest['files'].items():
        checked_path(name)
        require(fingerprint(files['task-materials/' + name]) == expected, 'Reference binding differs')
    for name, expected in lock['documentation'].items():
        checked_path(name)
        files[name] = read_locked(ROOT / name, expected)
    files['ADAPTER.json'] = encoded({key: lock[key] for key in (
        'format', 'candidate_id', 'delivery_adapter_version', 'skill_release_version',
        'delivery_status', 'native_evidence_status', 'payload_files', 'rules')})
    files['SHA256SUMS'] = ''.join(fingerprint(data)['sha256'] + '  ' + name + '\n'
                                for name, data in sorted(files.items())).encode('utf-8')
    prefix = lock['archive_root']
    checked_path(prefix)
    archive_files = {prefix + '/' + name: data for name, data in files.items()}
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_STORED) as archive:
        for name, data in sorted(archive_files.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 13, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(info, data)
    archive_bytes = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
        require(archive.testzip() is None, 'ZIP CRC mismatch')
        require({n: archive.read(n) for n in archive.namelist()} == archive_files,
                'ZIP contents differ')
    output.mkdir(parents=True)
    archive_name = lock['archive_filename']
    require(Path(archive_name).name == archive_name, 'Unsafe archive filename')
    (output / archive_name).write_bytes(archive_bytes)
    report = {'candidate_id': lock['candidate_id'],
              'delivery_adapter_version': lock['delivery_adapter_version'],
              'status': lock['delivery_status'], 'archive': archive_name,
              **fingerprint(archive_bytes), 'members': len(files),
              'payload_members': len(expected_names), 'payload_exact': True,
              'native_tests_run': False, 'files': {n: fingerprint(b) for n, b in sorted(files.items())}}
    (output / 'build-report.json').write_bytes(encoded(report))
    print(json.dumps({k: report[k] for k in ('archive', 'bytes', 'sha256', 'members', 'payload_exact')},
                     ensure_ascii=False))


if __name__ == '__main__':
    main()
