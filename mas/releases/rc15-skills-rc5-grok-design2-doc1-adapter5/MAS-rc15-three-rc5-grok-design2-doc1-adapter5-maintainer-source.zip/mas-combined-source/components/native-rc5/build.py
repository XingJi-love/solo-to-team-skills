#!/usr/bin/env python3
"""Build three isolated feedback candidates. Never install or call a native host."""
import argparse
import difflib
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
VERSION = "0.1.0-rc.5"
PLATFORMS = {"workbuddy", "deepseek", "openmaus"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def safe(name):
    p = PurePosixPath(name)
    require(not p.is_absolute() and ".." not in p.parts and "\\" not in name
            and p.as_posix() == name, "Unsafe member path")


def encode_json(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def record(data):
    return {"bytes": len(data), "sha256": sha(data)}


def read_locked(path, expected):
    require(path.is_file() and not path.is_symlink(), "Missing or symlinked input: " + str(path))
    data = path.read_bytes()
    require(record(data) == expected, "Input identity differs: " + str(path))
    return data


def archive(entries, stored=False):
    buffer = io.BytesIO()
    method = zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED
    with zipfile.ZipFile(buffer, "w", compression=method,
                         compresslevel=None if stored else 9) as z:
        for name, data in sorted(entries.items()):
            safe(name)
            info = zipfile.ZipInfo(name, (2026, 11, 13, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = method
            z.writestr(info, data)
    result = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(result)) as z:
        require(z.testzip() is None, "ZIP CRC failure")
        require(len(z.namelist()) == len(entries), "ZIP inventory differs")
        require({name: z.read(name) for name in z.namelist()} == entries,
                "ZIP content differs from payload")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "dist" / VERSION)
    args = parser.parse_args()
    out = args.out.resolve()
    require(ROOT in out.parents and out != ROOT, "Output must be inside this isolated source")
    source_manifest = json.loads((ROOT / "source-manifest.json").read_text())
    for name, expected in source_manifest["files"].items():
        safe(name)
        read_locked(ROOT / name, expected)

    lock = json.loads((ROOT / "baseline/input-lock.json").read_text())
    require(lock["status"] == "ready_local_candidate_only", "Inputs not ready")
    require(set(lock["new_versions"]) == PLATFORMS, "Unexpected platform set")
    source = ROOT / "baseline/payloads"
    require(not any(p.is_symlink() for p in source.rglob("*")), "Baseline symlink refused")
    require({p.relative_to(source).as_posix() for p in source.rglob("*") if p.is_file()}
            == set(lock["files"]), "Baseline inventory changed")
    baseline = {name: read_locked(source / name, expected)
                for name, expected in lock["files"].items()}
    require(len(baseline) == 15, "Expected 15 native baseline files")
    old_full = read_locked(ROOT / "baseline/core/workflow.md", lock["old_workflow"])
    new_full = read_locked(ROOT / "core/workflow.md", lock["new_workflow"])
    old, new = old_full.rstrip(b"\n"), new_full.rstrip(b"\n")
    require(len(new_full) - len(old_full) == 885, "Unexpected common-rule delta")
    require(b"/Users/" not in new_full and b"[TODO" not in new_full, "Private path or placeholder")

    operations_raw = (ROOT / "overlays/operations.json").read_bytes()
    require(sha(operations_raw) == lock["overlay_operations_sha256"], "Overlay lock changed")
    overlay = json.loads(operations_raw)
    allowed_overlay = {
        "openmaus/solo-to-team-openmaus/SKILL.md",
        "openmaus/solo-to-team-openmaus/references/roles-part-2.md",
    }
    require(set(overlay["files"]) == set(overlay["operations"]) == allowed_overlay,
            "Unexpected overlay files")
    require(sum(len(v) for v in overlay["operations"].values()) == 7, "Expected seven wording changes")
    revised = dict(baseline)
    for name, ops in overlay["operations"].items():
        original = baseline[name]
        expected = overlay["files"][name]
        require(record(original) == {"bytes": expected["before_bytes"],
                                     "sha256": expected["before_sha256"]}, "Overlay baseline differs")
        data = original
        for op in ops:
            before, after = op["before"].encode(), op["after"].encode()
            require(before and after and data.count(before) == 1, "Overlay splice is not unique")
            data = data.replace(before, after, 1)
        candidate = read_locked(ROOT / "overlays" / name,
                                {"bytes": expected["after_bytes"], "sha256": expected["after_sha256"]})
        require(data == candidate, "Overlay exceeds locked seven wording changes")
        revised[name] = data

    outputs = {}
    platform_rows = {}
    reverse_verified = []
    for platform, version in sorted(lock["new_versions"].items()):
        name = "solo-to-team-" + platform
        prefix = platform + "/" + name + "/"
        main_path = prefix + "SKILL.md"
        data = revised[main_path]
        old_version = lock["old_versions"][platform].encode()
        require(data.count(old) == 1, "Workflow splice not unique")
        require(data.count(old_version) == 2, "Expected two version markers")
        new_main = data.replace(old, new, 1).replace(old_version, version.encode())
        require(new_main.replace(new, old, 1).replace(version.encode(), old_version) == data,
                "Unexpected core/version change")
        revised[main_path] = new_main
        payload = {rel[len(platform) + 1:]: b for rel, b in revised.items() if rel.startswith(prefix)}
        require(len(payload) == 5, "Expected five native files per platform")
        if platform == "openmaus":
            require(sum("/references/" in n for n in payload) == 3, "OpenMaus reference shape changed")
            require(all(len(b) <= 32768 for n, b in payload.items() if n.endswith(".md")),
                    "OpenMaus native Markdown limit exceeded")
            zip_name = f"{name}-{version}-candidate.zip"
        else:
            zip_name = name + ".zip"
        zip_path = platform + "/" + zip_name
        outputs[zip_path] = archive(payload, stored=platform == "openmaus")
        packages = {zip_path: record(outputs[zip_path])}
        if platform == "deepseek":
            project_path = platform + "/" + name + "-project.zip"
            outputs[project_path] = archive({".dsh/skills/" + n: b for n, b in payload.items()})
            packages[project_path] = record(outputs[project_path])
        platform_rows[platform] = {
            "version": version, "main": main_path, **record(new_main),
            "characters": len(new_main.decode()), "payload_files": 5, "packages": packages,
            "native_save": "not verified for this revision",
            "native_loading": "not verified for this revision",
            "native_behavior": "not verified for this revision",
        }

    changed = sorted(n for n in baseline if baseline[n] != revised[n])
    unchanged = sorted(n for n in baseline if baseline[n] == revised[n])
    require(changed == lock["expected_changed"], "Unexpected native-file change set")
    require(len(unchanged) == lock["expected_unchanged_count"] == 11, "Unchanged count differs")
    for name in changed:
        data = revised[name]
        platform = name.split("/", 1)[0]
        if name.endswith("/SKILL.md"):
            data = data.replace(new, old, 1).replace(lock["new_versions"][platform].encode(),
                                                   lock["old_versions"][platform].encode())
        for op in reversed(overlay["operations"].get(name, [])):
            after, before = op["after"].encode(), op["before"].encode()
            require(data.count(after) == 1, "Reverse wording splice is not unique")
            data = data.replace(after, before, 1)
        require(data == baseline[name], "Reverse transformation did not restore baseline")
        reverse_verified.append(name)

    outputs.update(revised)
    difference = {
        "baseline_product": lock["baseline_product"], "changed": changed,
        "unchanged": unchanged, "added": [], "removed": [],
        "exact_reverse_to_baseline": reverse_verified,
        "shared_workflow_added_bytes": 885, "openmaus_wording_changes": 7,
        "files": {n: {"before": record(baseline[n]), "after": record(revised[n])}
                  for n in sorted(baseline)},
        "scope": "Native payload bytes only; no host execution or acceptance inferred.",
    }
    outputs["payload-diff.json"] = encode_json(difference)
    outputs["payload-changes.patch"] = "".join(
        "".join(difflib.unified_diff(baseline[n].decode().splitlines(True),
                                     revised[n].decode().splitlines(True),
                                     fromfile="doc3/" + n, tofile="rc5-candidate/" + n))
        for n in changed).encode()
    manifest = {
        "format": "solo-to-team.three-platform-feedback-candidate",
        "version": VERSION, "status": "local_candidate_not_published",
        "grok": "excluded; separate offline save design is not an installed-skill claim",
        "baseline_product": lock["baseline_product"], "workflow": record(new_full),
        "platforms": platform_rows, "roles": 16, "groups": 6, "suggested_memberships": 26,
        "native_files": 15, "native_changed": 4, "native_unchanged": 11,
        "archives": 4, "files": {n: record(b) for n, b in sorted(outputs.items())},
        "validation": "Exact reversible byte changes, native shape, UTF-8 limits, ZIP CRC/readback only. No native installation, business, rollback or publication claim.",
    }
    outputs["manifest.json"] = encode_json(manifest)
    outputs["SHA256SUMS"] = "".join(sha(b) + "  " + n + "\n"
                                      for n, b in sorted(outputs.items())).encode()
    for rel, data in outputs.items():
        safe(rel)
        target = out / rel
        require(not target.is_symlink(), "Output symlink refused")
        require(not target.exists() or target.is_file() and target.read_bytes() == data,
                "Refusing to replace differing output: " + rel)
    for rel, data in outputs.items():
        target = out / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_bytes(data)
    print(json.dumps({"version": VERSION, "output_files": len(outputs),
                      "native_changed": len(changed), "native_unchanged": len(unchanged),
                      "archives": 4, "platforms": platform_rows}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
