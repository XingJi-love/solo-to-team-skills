# 三端反馈修订 rc5：便携维护源（本机测试候选）

只生成 WorkBuddy / DeepSeek Harness / OpenMausBot 的离线候选。WB/DSH 为0.1.0-rc.5，OM为0.1.0-rc.5-om.4。没有Grok安装包，没有安装/联网/原生测试动作，不代表新版本已通过宿主验证。

## 重建

需要Python 3.9或以上及标准库，无需额外依赖。在本目录执行：

```sh
python3 -B build.py
```

结果在`dist/0.1.0-rc.5/`。包含15件原生文件、4个ZIP、manifest/SHA与精确差分。WB标准ZIP、DSH标准及项目ZIP、OM五文件ZIP仅遵循已有形状；本源码不替代当前平台采用说明或原生验收。脚本拒绝覆盖不同字节的已有输出。

## 输入与保护

- `baseline/input-lock.json`锁当前doc3主ZIP身份及15件提取原件；原ZIP是来源记录，不是重建所需外部依赖。
- `baseline/core/workflow.md`为原共享核心；`core/workflow.md`为已核三段证据补句，总增加885字节。
- `overlays/operations.json`限定OM七处文字；两份overlay仅用于精确核对。未经允许不能把其他变化夹入覆盖。
- 三主文核心/版本变化可逆；OM七处变化再逆向后回到实际doc3基线。原生件4改11同，0增删；完整16席6群、许可和其他参考保留。
- 保留路径安全、唯一替换、ZIP CRC/原字节回读、OM5件/3参考与Markdown每件≤32KiB检查。
- `source-manifest.json`列源码输入。源码变更后应形成新候选及新清单，不能对旧候选静默改锁。

构建方法沿用既有平台规则构建器的锁定基线、确定性ZIP和原字节保护；本版限定三端并增加有界OM覆盖。许可见LICENSE及各平台原LICENSE。共享核心和原生文件的历史来源由输入锁保留。

静态构建只证明文件结构与指定差分；旧rc4有限原生记录仍属于旧版本。实例证据、资料可见性、终态指纹和OM实际群规读取的新版原生样本另核。不重跑完整MAS产品或已通过业务来替代这些节点。
