#!/usr/bin/env python3
"""Read actual new candidate, compare locked composition, and check its extracted local targets."""
import argparse, json
from pathlib import Path
from build_incremental import HERE, ROOT, archive, check_manifest, compose, dump, require, sha
def main(a):
    expected, scope=compose(a)
    data=archive(a.zip.read_bytes(),'actual candidate')
    require(data==expected,'Actual candidate differs from locked source composition')
    check_manifest(data)
    release=json.loads(data[ROOT+'checksums.json'])
    for n,h in release['files'].items():require(sha(data[ROOT+n])==h,'MAS checksum differs: '+n)
    addon=json.loads(data[ROOT+'skills-add-on/manifest.json'])
    for n,r in addon['files'].items():
        b=data[ROOT+'skills-add-on/'+n]
        require(sha(b)==r['sha256'] and len(b)==r['bytes'],'Platform manifest differs: '+n)
    preview=a.preview.resolve()
    require(HERE in preview.parents and not preview.exists(),'Preview must be new under this assembly')
    preview.mkdir(parents=True)
    for n,b in data.items():
        p=preview/n
        require(preview in p.resolve().parents,'Extraction escaped preview')
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
        require(p.read_bytes()==b,'Extracted bytes differ: '+n)
    for item in scope['links']:
        require((preview/item['target']).is_file(),'Extracted link missing: '+item['target'])
    report={'sha256':sha(a.zip.read_bytes()),'bytes':a.zip.stat().st_size,'members':len(data),
            'all_members_equal_locked_sources':True,'extracted_members':len(data),
            'local_targets_exist':len(scope['links']),'versions':scope['platform_versions'],
            'difference_from_doc1':scope['difference_from_doc1'],
            'scope':'Actual archive readback and filesystem targets only; not browser or native-host acceptance'}
    target=a.report.resolve()
    require(HERE in target.parents and not target.exists(),'Report must be new under this assembly')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(dump(report))
    print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--lock',type=Path,default=HERE/'input-lock.json')
    p.add_argument('--baseline',type=Path,required=True);p.add_argument('--platforms',type=Path,required=True)
    p.add_argument('--documents',type=Path,required=True);p.add_argument('--zip',type=Path,required=True)
    p.add_argument('--preview',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
    main(p.parse_args())
