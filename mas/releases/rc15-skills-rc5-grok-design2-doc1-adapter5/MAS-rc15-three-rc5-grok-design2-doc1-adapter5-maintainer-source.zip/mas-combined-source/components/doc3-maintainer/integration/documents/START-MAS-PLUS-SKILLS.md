# MAS rc15 ＋ 四端Skill rc4（OpenMaus rc4-om.3）· 核心规则v2候选

这份发布候选保留完整MAS，另加四款平台专用协作技能。Grok、WorkBuddy、DeepSeek采用0.1.0-rc.4，OpenMaus采用0.1.0-rc.4-om.3；各平台采用方式不同，不是通用一键安装包。

## 第一次拿到包，先做这一步

先解压完整组合 ZIP，打开其中 `Solo-to-Team/START-MAS-PLUS-SKILLS.html`。本页和四端采用说明都在主包内，不依赖维护者电脑上的文件。已有能正常使用的账号／模型连接继续沿用；本包不替你开通账号、购买额度或扩大权限。

| 所用平台 | 主包内要拿的文件 | 是否解压这份内层包 |
|---|---|---|
| WorkBuddy | [单技能 ZIP](skills-add-on/workbuddy/solo-to-team-workbuddy.zip) · [采用步骤](skills-add-on/workbuddy/开始使用.md) | 首次安装保持 ZIP，走“添加技能→上传技能”；同名不同版见采用步骤。用户级生效，不是仅当前对话。 |
| OpenMausBot | [单技能 ZIP](skills-add-on/openmaus/solo-to-team-openmaus-0.1.0-rc.4-om.3-candidate.zip) · [采用步骤](skills-add-on/openmaus/开始使用.md) | 解压后走目标 Bot 的 `/learn`，读取主文与三份参考。主包已附同版展开目录，可直接用。 |
| DeepSeek Harness | [项目技能 ZIP](skills-add-on/deepseek/solo-to-team-deepseek-project.zip) · [采用步骤](skills-add-on/deepseek/开始使用.md) | 先核真实项目根与同名旧件，再从解压副本放入 `.dsh/skills/solo-to-team-deepseek/`。 |
| Grok Bot | [保存稿 ZIP](skills-add-on/grok/solo-to-team-grok.zip) · [采用步骤](skills-add-on/grok/开始使用.md) | 解压取完整 `SKILL.md`；核真实保存范围与同名对象后采用。同账号新 Bot 不证明隔离。 |

先核目标里有没有同名 Skill：同版且已核可用就直接复用；不同版按已有适用替换授权保留旧件再处理，没有替换依据就停在写入之前。不要把安装 Skill 当成建好团队；需要成员时沿用现有团队，或另按保留的 MAS 团队入口处理。失败后的撤回办法与未核入口见各平台说明，不删除其他技能或已完成成果。

MAS以rc15为底座，保留核心规则v2及对应模板、说明与示例。本轮另补当前采用入口与四平台rc4规则传播；历史文件与平台实测记录按各自版本保留。16席、6群、26条建议群籍、建队台与各端团队配置保留。小任务只安排所需岗位，不缩减完整系统，不自动建立整队或覆盖现役规则。

核心规则修订v2把任务阶段与叫开工、续期、升级记录分开；新一单或新一轮用新任务标识，旧单补记不关闭新单。核验结果与接受权限分开：当前版本核验通过、既定独审等条件满足后，有明确适用接受授权的有权者直接作出接受决定，不重复询问；没有接受决定或适用授权时，核验通过也不销项。独审要求和其他权限边界不变。

此前OpenMaus rc3-om.3已取得限定原生同题闭环：正式项目内由制作席产出Markdown与CSV，另一席实际审核，首席在原发起对话分别附回两件，维护者实际下载、全文核读，与生产原件逐字一致。这只证明本次三席、两件合成任务；物理打印分页、全16席、群附件、跨机和长期稳定性未据此证明。om.2旧业务三附件失败、后续独立84字节附件小样本分别留档，不被本次成功回填。

此前WorkBuddy rc3已取得限定原生同题闭环：主理人实际读取Skill，创建本单团队并调用两个独立成员完成制作和审核，在原任务展示Markdown与CSV，维护者实际打开两件并核对内容及输入保全。仅证明本次三个上下文、两件合成任务；不等于永久注册16席，也未证明每名成员自动加载全部Skill或附件。宿主另生成本题项目记录，不能说只写了两件交付物；未测试跨机、上传分享或长期稳定性。

Grok rc3朋友试用结果仍待回，不能称本次原生通过。DeepSeek Harness rc3已有有限文字修改与明确任务级交接后的同项目新会话接续；不代表含糊交接首轮自动恢复、全16席、跨机或后台恢复。建队台已有一条真实有限链：用户本人完成默认OpenMaus导出、改名保存重开、Tab＋空格岗位切换、移除情报官保存，再重新打开原文件恢复16席；维护者核对实际文件，rc13与rc15的HTML及42件源文件逐字一致，可按相同制品承接这批结果。其他导出、完整无障碍及全功能未据此证明。

上述rc3／om.3记录保留各自旧版已核范围，不移作新版本结果。当前rc4新增了WorkBuddy有限原生核收：本机5.9.3同名更新后，实际Skill调用、版本指纹及三份输入读取轨迹可见，维护者从原任务打开回归文件，正文独立核对通过。DeepSeek Harness本轮在既有项目明确选择slash技能，核到版本与三份输入读取轨迹，原会话结果可打开，正文独立核对通过；这是项目级采用，不是全局安装。

OpenMaus rc4-om.3同名原生更新及四份Markdown已核同；同一既有测试Bot在正式项目中完成一题有限规则处理，维护者从原对话实际下载结果并核与原文件逐字一致，正文独立核对通过。更新后宿主旧修订目录没有继续保留，独立旧件备份仍在；回退和恢复未实测，不把旧目录存在当作可靠恢复依据。

本轮三端各一题有限原生增量已核，没有重跑多席业务链，不证明全16席、全员自动加载、跨机或长期稳定性。Grok朋友继续原rc3测试包等待回件，现役Grok团队不动，新rc4无原生通过结论；整套四端验收仍未完成。各版本与边界见当前版本表，本机候选不等于已经公开发布。

## 入口

- [原 MAS 工作台](index.html)
- [16席 / 6群建队台](team-16/index.html)
- [带底稿开始](start-with-files/index.html)
- [更新已有团队](update-team/index.html)
- [原MAS中文安装说明](team-16/SETUP.zh.md)
- [原MAS English setup](team-16/SETUP.en.md)
- [原MAS验证记录及未完项](team-16/VERIFICATION.zh.md)
- [六群完整规则](team-16/rules/groups.zh.md)
- [原有四技能](core/skills-original/README.md)
- [Grok Bot · rc4](skills-add-on/grok/开始使用.md)
- [OpenMausBot · rc4-om.3 原生学习保存](skills-add-on/openmaus/开始使用.md)
- [WorkBuddy · rc4](skills-add-on/workbuddy/开始使用.md)
- [DeepSeek Harness · rc4](skills-add-on/deepseek/开始使用.md)
- [当前平台版本和证据边界](skills-add-on/当前版本与入口.md)
- [新增技能混合版本清单](skills-add-on/manifest.json)
- [组合包校验清单](combined-checksums.json)
- [原MAS许可与例外](NOTICE)

## 校验范围

原MAS的职责、群规、业务代码、媒体与许可保留；本次两支核心规则及其配套文档的差异单独列于校验清单。新增四平台Skill分别随附原许可，不因本次装配改变作用范围或授权。文件一致、压缩包可打开或链接存在，都不能代替实际业务验收。
