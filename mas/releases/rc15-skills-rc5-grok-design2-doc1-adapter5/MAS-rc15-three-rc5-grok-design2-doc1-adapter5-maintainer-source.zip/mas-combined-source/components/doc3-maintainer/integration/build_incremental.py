#!/usr/bin/env python3
"""Locked incremental assembly; pending inputs cannot generate an archive."""
import argparse, hashlib, html, io, json, posixpath, re, stat, zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit
HERE=Path(__file__).resolve().parent
ROOT='Solo-to-Team/'
ADD=ROOT+'skills-add-on/'
MANIFEST=ROOT+'combined-checksums.json'
PLATFORMS={'grok','openmaus','workbuddy','deepseek'}
PROTECTED=('core/','team-16/','start-with-files/','update-team/')
GENERATED={MANIFEST,ROOT+'checksums.json',ADD+'manifest.json',ADD+'SHA256SUMS'}
def require(ok,message):
    if not ok: raise ValueError(message)
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(v): return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def safe(n):
    p=PurePosixPath(n)
    require(n and not n.startswith('/') and '\\' not in n and '\x00' not in n,'Unsafe path '+repr(n))
    require('..' not in p.parts and p.as_posix()==n.rstrip('/') and ':' not in p.parts[0],'Unsafe path '+repr(n))
def archive(b,label):
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        names=z.namelist()
        require(len(names)==len(set(names))==len({n.casefold() for n in names}),label+': duplicate paths')
        require(sum(i.file_size for i in z.infolist())<128*1024*1024,label+': expansion limit')
        for i in z.infolist():
            safe(i.filename);require(not stat.S_ISLNK(i.external_attr>>16),label+': symlink')
        require(z.testzip() is None,label+': CRC failure')
        return {i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
def locked_directory(folder,records):
    require(folder.is_dir() and not folder.is_symlink(),'Missing/symlinked input directory')
    require(not any(p.is_symlink() for p in folder.rglob('*')),'Input symlinks refused')
    data={p.relative_to(folder).as_posix():p.read_bytes() for p in folder.rglob('*') if p.is_file()}
    require(set(data)==set(records),'Input inventory differs: '+str(folder))
    require(len(data)==len({n.casefold() for n in data}),'Case-insensitive input collision')
    for n,r in records.items():
        safe(n);require(sha(data[n])==r['sha256'] and len(data[n])==r['bytes'],'Input bytes differ: '+n)
    return data
def skill_version(b):
    text=b.decode();require(text.startswith('---\n'),'SKILL front matter missing')
    versions=re.findall(r'^\s*version:\s*["\']?([^"\'\s]+)["\']?\s*$',text.split('\n---',1)[0],re.M)
    require(len(versions)==1,'Expected one SKILL metadata version')
    return versions[0]
def check_links(files,documents):
    checked=[]
    for name in sorted(documents):
        pattern=r'href=["\']([^"\']+)["\']' if name.endswith('.html') else r'\[[^\]]*\]\(([^)]+)\)'
        for raw in re.findall(pattern,files[name].decode()):
            href=html.unescape(raw.strip().strip('<>'));u=urlsplit(href)
            if u.scheme or u.netloc or not u.path:continue
            target=posixpath.normpath(posixpath.join(posixpath.dirname(name),unquote(u.path)))
            require(target.startswith(ROOT) and target in files,'Missing/escaped link: '+name+' -> '+href)
            checked.append({'source':name,'href':href,'target':target})
    return checked
def check_manifest(files):
    m=json.loads(files[MANIFEST])
    require(set(m['files'])==set(files)-{MANIFEST},'Combined manifest inventory mismatch')
    for n,r in m['files'].items():
        require(sha(files[n])==r['sha256'] and len(files[n])==r['bytes'],'Manifest mismatch: '+n)
    require(m['archive_members']==len(files),'Manifest count mismatch')
    return m
def compose(args):
    lock=json.loads(args.lock.read_text())
    require(lock['status']=='ready','Inputs pending: no candidate ZIP may be generated')
    require(set(lock['platforms'])==PLATFORMS,'Expected four platform inputs')
    require(lock['core_rules_revision']=='issues23-24-v2','Unexpected core revision')
    require(re.fullmatch(r'[A-Za-z0-9._-]+',lock['candidate']),'Unsafe candidate name')
    bb=args.baseline.read_bytes()
    require(sha(bb)==lock['baseline']['sha256'] and len(bb)==lock['baseline']['bytes'],'Baseline identity differs')
    base=archive(bb,'doc1 baseline')
    require(len(base)==lock['baseline']['files'] and all(n.startswith(ROOT) for n in base),'Baseline inventory differs')
    prior=check_manifest(base);require(prior['core_rules_revision']==lock['core_rules_revision'],'Baseline core differs')
    release=json.loads(base[ROOT+'checksums.json'])
    require(len(release['files'])==229,'Expected 230-member MAS base')
    for n,h in release['files'].items():require(sha(base[ROOT+n])==h,'Base checksum mismatch: '+n)
    core=json.loads(base[ROOT+'core/checksums.json'])
    require(core=={n[len(ROOT+'core/'):]:sha(b) for n,b in base.items() if n.startswith(ROOT+'core/') and n!=ROOT+'core/checksums.json'},'Core checksum mismatch')
    records={}
    for p,s in lock['platforms'].items():
        require(s['version'] and s['files'] and s['archives'],'Platform lock incomplete: '+p)
        for n,r in s['files'].items():
            require(n.startswith(p+'/') and n not in records,'Platform ownership differs: '+n);records[n]=r
    payload=locked_directory(args.platforms,records);versions={};zip_checks=[]
    for p,s in sorted(lock['platforms'].items()):
        prefix=p+'/solo-to-team-'+p+'/'
        require(prefix+'SKILL.md' in payload,'Main missing: '+p)
        versions[p]=skill_version(payload[prefix+'SKILL.md'])
        require(versions[p]==s['version'],'Actual SKILL version differs: '+p)
        require({n for n in s['files'] if n.endswith('.zip')}=={a['path'] for a in s['archives']},'ZIP contract missing: '+p)
        for a in s['archives']:
            require(a['path'].startswith(p+'/') and a['expanded_prefix']==prefix,'Archive ownership differs')
            safe(a['archive_prefix'])
            expected={a['archive_prefix']+n[len(prefix):]:b for n,b in payload.items() if n.startswith(prefix)}
            got=archive(payload[a['path']],a['path'])
            require(got==expected and expected,'ZIP/expanded bytes differ: '+a['path'])
            zip_checks.append({'path':a['path'],'files':len(got),'equal_expanded':True})
        if p=='openmaus':
            content={n:b for n,b in payload.items() if n.startswith(prefix)}
            require(len(content)==5 and sum('/references/' in n for n in content)==3,'OpenMaus five-file shape differs')
            require(all(len(b)<=32768 for n,b in content.items() if n.endswith('.md')),'OpenMaus size exceeded')
    require(lock['documents'] and set(lock['documents'])<=set(lock['document_allowlist']),'Adoption docs pending/outside allowlist')
    docs=locked_directory(args.documents,lock['documents'])
    for n in docs:
        require(not n.startswith(PROTECTED) and ROOT+n in base,'Protected/unmapped document: '+n)
    note=docs.get('skills-add-on/openmaus/给Bot读的安装指令.txt',base[ADD+'openmaus/给Bot读的安装指令.txt']).decode()
    require(versions['openmaus'] in note and sha(payload['openmaus/solo-to-team-openmaus/SKILL.md']) in note,'OM installation note version/hash differs')
    replaced={ROOT+n for n in lock['replace_baseline_payloads']}
    require(replaced and replaced<=set(base),'Missing baseline payload mapping')
    require(all(n.startswith(ADD) and (n.endswith('.zip') or '/solo-to-team-' in n) for n in replaced),'Unexpected payload removal')
    data={n:b for n,b in base.items() if n not in replaced and n not in GENERATED}
    for n,b in payload.items():
        require(ADD+n not in data,'Payload collides: '+n);data[ADD+n]=b
    for n,b in docs.items():data[ROOT+n]=b
    addon={n[len(ADD):]:b for n,b in data.items() if n.startswith(ADD)}
    addon['manifest.json']=dump({'format':'solo-to-team.mixed-platform-skills','combination':lock['candidate'],'release_status':'candidate','platform_versions':versions,'baseline_combination_sha256':sha(bb),'platform_source_manifest_sha256':lock['platform_source_manifest_sha256'],'core_rules_revision':lock['core_rules_revision'],'validation_scope':'Assembly verifies bytes and relative references only. Historical native samples do not prove rc4 business regression; see 当前版本与入口.md.','files':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(addon.items())}})
    addon['SHA256SUMS']=''.join(f'{sha(b)}  {n}\n' for n,b in sorted(addon.items())).encode()
    data.update({ADD+n:b for n,b in addon.items()})
    release['product_version']=lock['base_product_version'];release['navigation_revision']=lock['candidate']
    release['files']={n:sha(data[ROOT+n]) for n in release['files']}
    data[ROOT+'checksums.json']=dump(release)
    require(all(data.get(n)==b for n,b in base.items() if n[len(ROOT):].startswith(PROTECTED)),'Protected core/workbench changed')
    rows={n:{'sha256':sha(b),'bytes':len(b),'origin':'doc1-preserved' if base.get(n)==b else ('adoption-doc3' if n in {ROOT+r for r in docs} else 'platform-'+versions[n[len(ADD):].split('/')[0]] if n.startswith(ADD) and n[len(ADD):].split('/')[0] in PLATFORMS else 'adoption-doc3-or-metadata')} for n,b in sorted(data.items())}
    data[MANIFEST]=dump({'format':'solo-to-team.additive-combination','version':lock['candidate'],'release_status':'candidate','baseline_archive_sha256':sha(bb),'core_rules_revision':lock['core_rules_revision'],'platform_versions':versions,'roles':16,'groups':6,'suggested_memberships':26,'archive_members':len(rows)+1,'self_excluded':MANIFEST,'files':rows})
    diff={'changed':sorted(n[len(ROOT):] for n in base.keys()&data.keys() if base[n]!=data[n]),'added':sorted(n[len(ROOT):] for n in data.keys()-base.keys()),'removed':sorted(n[len(ROOT):] for n in base.keys()-data.keys())}
    require(diff==lock['expected_difference'],'Actual difference not precisely sealed in lock')
    require(len(data)==lock['expected_output_members'],'Output inventory differs')
    documents={ROOT+n for n in docs if n.endswith(('.md','.html'))}|{n for n in data if n.startswith(ADD) and n.endswith('.md')}
    links=check_links(data,documents);check_manifest(data)
    return data,{'candidate':lock['candidate'],'platform_versions':versions,'members':len(data),'difference_from_doc1':diff,'unchanged':sum(data.get(n)==b for n,b in base.items()),'archives_equal_expanded':zip_checks,'links':links,'broken_links':0,'protected_core_and_workbench_bytes_identical':True,'scope':'Static local assembly; not browser/native/installation/business acceptance'}
def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--lock',type=Path,default=HERE/'input-lock.json');p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--platforms',type=Path,required=True);p.add_argument('--documents',type=Path,required=True)
    p.add_argument('--output',type=Path,default=HERE/'output');p.add_argument('--check',action='store_true',help='Validate without writing ZIP')
    return p
def main(args):
    data,report=compose(args)
    if args.check:print(json.dumps(report,ensure_ascii=False));return
    out=args.output.resolve();require(HERE in out.parents and not out.exists(),'Output must be new directory below this assembly')
    out.mkdir(parents=True);target=out/('Solo-to-Team-MAS-'+report['candidate']+'.zip')
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_STORED) as z:
        for n,b in sorted(data.items()):
            i=zipfile.ZipInfo(n,(2026,11,13,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|0o644)<<16;z.writestr(i,b)
    require(archive(target.read_bytes(),target.name)==data,'Written archive differs')
    report.update(artifact=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size)
    (out/'build-verification.json').write_bytes(dump(report));(out/'SHA256SUMS').write_text(f"{report['sha256']}  {target.name}\n")
    print(json.dumps({k:report[k] for k in ['artifact','sha256','bytes','members']},ensure_ascii=False))
if __name__=='__main__':main(parser().parse_args())
