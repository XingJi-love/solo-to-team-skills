#!/usr/bin/env python3
"""Rebuild doc1 from its sources, build rc4 from source, and apply the locked doc3 integration."""
import argparse
import datetime
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import platform
import shutil
import stat
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def require(ok, message):
    if not ok:
        raise ValueError(message)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def read_source(path, expected):
    require(path.is_file() and not path.is_symlink(), 'Input must be a regular source ZIP: ' + path.name)
    data = path.read_bytes()
    require(len(data) == expected['bytes'] and sha(data) == expected['sha256'], 'Source ZIP fingerprint mismatch: ' + path.name)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        require(len(names) == len(set(names)) == len({n.casefold() for n in names}), 'Duplicate source paths')
        require(sum(i.file_size for i in infos) < 128 * 1024 * 1024, 'Excessive source expansion')
        for i in infos:
            n = i.filename
            q = PurePosixPath(n)
            require(n and not q.is_absolute() and '\\' not in n and '\x00' not in n and '..' not in q.parts
                    and ':' not in q.parts[0] and q.as_posix() == n.rstrip('/')
                    and q.parts[0] == expected['prefix'], 'Unsafe source member: ' + repr(n))
            mode = i.external_attr >> 16
            require(not stat.S_ISLNK(mode), 'Source symlink refused')
            require(stat.S_IFMT(mode) in (0, stat.S_IFREG, stat.S_IFDIR), 'Special source member refused')
        require(z.testzip() is None, 'Source CRC failed')
        files = {i.filename: z.read(i) for i in infos if not i.is_dir()}
        require(len(files) == expected['files'], 'Unexpected source member count')
    return files

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for option in ('mas-source-zip', 'skills-source-zip', 'openmaus-source-zip',
                   'doc1-entry-source-zip', 'platform-rc4-source-zip'):
        ap.add_argument('--' + option, type=Path, required=True)
    ap.add_argument('--work-dir', type=Path, required=True)
    args = ap.parse_args()
    lock = json.loads((ROOT / 'rebuild-inputs.json').read_text())
    require(lock['status'] == 'ready', 'Maintainer chain pending final inputs/product identity; no cold build started')
    require(sys.version_info >= (3, 9), 'Python 3.9 or later is required')
    require(shutil.which('node') is not None, 'Existing Node.js required; no installation is performed')
    require(not args.work_dir.exists() and not args.work_dir.is_symlink(), 'Use a new work directory')
    require(lock['integration_files'] and lock['final_sha256'] and lock['final_files'], 'Incomplete final source lock')
    sources = {'mas': args.mas_source_zip, 'skills': args.skills_source_zip,
               'openmaus': args.openmaus_source_zip, 'doc1_entry': args.doc1_entry_source_zip,
               'platform_rc4': args.platform_rc4_source_zip}
    files = {}
    for key, path in sources.items():
        entries = read_source(path, lock['inputs'][key])
        # The old three archives will be extracted by their original locked doc1 wrapper.
        if key in ('doc1_entry', 'platform_rc4'):
            require(not (files.keys() & entries.keys()), 'Source archive collision')
            files.update(entries)
    folder = ROOT / 'integration'
    require(not any(p.is_symlink() for p in folder.rglob('*')), 'Integration symlinks refused')
    local = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in folder.rglob('*') if p.is_file()}
    require(set(local) == set(lock['integration_files']), 'Integration source inventory differs')
    for name, data in local.items():
        require(sha(data) == lock['integration_files'][name], 'Integration source changed: ' + name)
        require(name not in files, 'Integration/archive collision')
        files[name] = data
    work = args.work_dir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    for name, data in files.items():
        dest = work / name
        require(work in dest.resolve().parents, 'Unsafe source destination')
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open('xb') as f:
            f.write(data)
    before = {name: sha(data) for name, data in sorted(files.items())}
    write_json(work / 'source-inputs-before.json', before)
    logs = work / 'logs'
    logs.mkdir()
    doc1 = work / lock['inputs']['doc1_entry']['prefix']
    platform_source = work / lock['inputs']['platform_rc4']['prefix']
    baseline_work = work / 'doc1-source-rebuild'
    baseline = baseline_work / 'integration/output' / lock['baseline_filename']
    integration = work / 'integration'
    final = integration / 'output' / lock['final_filename']
    record = {'start_utc': now(), 'python': sys.version, 'platform': platform.platform(),
              'input_zips': {k: {'path': str(p.resolve()), **lock['inputs'][k]} for k, p in sources.items()},
              'commands': [], 'result': 'running',
              'scope': 'One local complete source rebuild; no new native host, browser, business or cross-machine acceptance.'}

    def run(name, command, cwd):
        print('Running ' + name, flush=True)
        started = now()
        result = subprocess.run(command, cwd=cwd, capture_output=True)
        stdout, stderr = logs / (name + '.stdout'), logs / (name + '.stderr')
        stdout.write_bytes(result.stdout)
        stderr.write_bytes(result.stderr)
        record['commands'].append({'name': name, 'argv': command, 'cwd': str(cwd),
            'start_utc': started, 'end_utc': now(), 'exit': result.returncode,
            'stdout': str(stdout.relative_to(work)), 'stderr': str(stderr.relative_to(work)),
            'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
        write_json(work / 'run-record.json', record)
        require(result.returncode == 0, name + ' failed; preserve logs and diagnose before another run')

    try:
        run('01-doc1-from-three-sources', [sys.executable, '-B', 'rebuild.py',
            '--mas-source-zip', str(args.mas_source_zip.resolve()),
            '--skills-source-zip', str(args.skills_source_zip.resolve()),
            '--openmaus-source-zip', str(args.openmaus_source_zip.resolve()),
            '--work-dir', str(baseline_work)], doc1)
        require(sha(baseline.read_bytes()) == lock['baseline_sha256'], 'Source-built doc1 baseline differs')
        old_record = json.loads((baseline_work / 'run-record.json').read_text())
        require(old_record['result'] == 'pass' and old_record['source_inputs_unchanged'] == 329,
                'Original doc1 source invariance not confirmed')
        run('02-platform-rc4-from-source', [sys.executable, '-B', 'build.py'], platform_source)
        dist = platform_source / lock['platform_dist']
        input_lock = json.loads((integration / 'input-lock.json').read_text())
        require(sha((dist / 'manifest.json').read_bytes()) == input_lock['platform_source_manifest_sha256'],
                'Rebuilt platform manifest differs')
        selected = {n: r for spec in input_lock['platforms'].values() for n, r in spec['files'].items()}
        actual_names = {p.relative_to(dist).as_posix() for p in dist.rglob('*') if p.is_file()}
        require(actual_names == set(selected) | {'manifest.json', 'SHA256SUMS'}, 'Rebuilt platform output inventory differs')
        for name, expected in selected.items():
            data = (dist / name).read_bytes()
            require(sha(data) == expected['sha256'] and len(data) == expected['bytes'],
                    'Rebuilt platform payload differs: ' + name)
            dest = integration / 'platforms' / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open('xb') as f:
                f.write(data)
        common = ['--baseline', str(baseline), '--platforms', str(integration / 'platforms'),
                  '--documents', str(integration / 'documents')]
        run('03-incremental-combination', [sys.executable, '-B', 'build_incremental.py',
            *common, '--output', str(integration / 'output')], integration)
        run('04-actual-archive-and-extraction', [sys.executable, '-B', 'verify_candidate.py',
            *common, '--zip', str(final), '--preview', str(integration / 'preview'),
            '--report', str(integration / 'output/extracted-verification.json')], integration)
        require(sha(final.read_bytes()) == lock['final_sha256'] and final.stat().st_size == lock['final_bytes'],
                'Final product identity differs')
        with zipfile.ZipFile(final) as z:
            require(z.testzip() is None and len([i for i in z.infolist() if not i.is_dir()]) == lock['final_files'],
                    'Final product member/CRC differs')
        after = {name: sha((work / name).read_bytes()) for name in before}
        write_json(work / 'source-inputs-after.json', after)
        require(before == after, 'Extracted outer source input changed')
        require(all(sha(p.read_bytes()) == lock['inputs'][k]['sha256'] for k, p in sources.items()),
                'Original source ZIP changed')
        record.update(result='pass', source_inputs_unchanged=len(before), source_inputs_scope='doc1 entry + rc4 source + new integration documents',
                      baseline_source_inputs_unchanged=329, input_zips_unchanged=5,
                      final_archive=str(final.relative_to(work)), final_sha256=sha(final.read_bytes()),
                      final_bytes=final.stat().st_size, final_members=lock['final_files'])
    except Exception as error:
        record.update(result='failed', error=str(error))
        raise
    finally:
        record['end_utc'] = now()
        write_json(work / 'run-record.json', record)
    print(json.dumps({k: record[k] for k in ('result', 'final_sha256', 'final_bytes', 'final_members',
          'source_inputs_unchanged', 'baseline_source_inputs_unchanged', 'input_zips_unchanged')}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
