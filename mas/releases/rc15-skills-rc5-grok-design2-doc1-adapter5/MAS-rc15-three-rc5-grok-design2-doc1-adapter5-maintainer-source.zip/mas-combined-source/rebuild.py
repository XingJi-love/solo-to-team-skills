#!/usr/bin/env python3
"""Offline source-to-product relay. No installation, host access or network calls."""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def need(ok, message):
    if not ok:
        raise ValueError(message)


def fp(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def source_check():
    expected = json.loads((ROOT / 'source-manifest.json').read_text('utf-8'))['files']
    actual = {}
    for p in ROOT.rglob('*'):
        need(not p.is_symlink(), 'Source symlink is not allowed')
        if p.is_file() and p.name != 'source-manifest.json':
            actual[p.relative_to(ROOT).as_posix()] = fp(p.read_bytes())
        elif p.is_file() and p != ROOT / 'source-manifest.json':
            actual[p.relative_to(ROOT).as_posix()] = fp(p.read_bytes())
    need(actual == expected, 'Complete source inventory or bytes changed')
    return actual


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work-dir', required=True, type=Path)
    args = parser.parse_args()
    need(sys.version_info >= (3, 9), 'Python 3.9 or later is required')
    need(shutil.which('node') is not None, 'Existing Node.js is required; no software is installed')
    work = args.work_dir.resolve()
    need(not work.exists() and work != ROOT and ROOT not in work.parents,
         'Use a new work directory outside the immutable source directory')
    before = source_check()
    lock = json.loads((ROOT / 'rebuild-lock.json').read_text('utf-8'))
    need(lock['status'] == 'ready', 'Final inputs are not locked')
    work.mkdir(parents=True)
    shutil.copytree(ROOT / 'components', work / 'components')
    shutil.copytree(ROOT / 'assembly', work / 'assembly')
    shutil.copytree(ROOT / 'dependencies', work / 'dependencies')
    logs = work / 'logs'
    logs.mkdir()
    record = {'started_utc': datetime.now(timezone.utc).isoformat(),
              'steps': [], 'scope': lock['scope'], 'result': 'in_progress'}

    def run(name, command, cwd):
        result = subprocess.run(command, cwd=cwd, capture_output=True, text=True)
        (logs / (name + '.stdout')).write_text(result.stdout, encoding='utf-8')
        (logs / (name + '.stderr')).write_text(result.stderr, encoding='utf-8')
        record['steps'].append({'name': name, 'returncode': result.returncode})
        (work / 'run-record.json').write_bytes(encoded(record))
        need(result.returncode == 0, name + ' failed; see work logs')

    old = work / 'components/doc3-maintainer'
    old_lock = json.loads((old / 'rebuild-inputs.json').read_text('utf-8'))
    options = {'mas': 'mas-source-zip', 'skills': 'skills-source-zip',
               'openmaus': 'openmaus-source-zip', 'doc1_entry': 'doc1-entry-source-zip',
               'platform_rc4': 'platform-rc4-source-zip'}
    command = [sys.executable, '-B', 'rebuild.py']
    for key, option in options.items():
        dependency = work / 'dependencies' / old_lock['inputs'][key]['filename']
        expected = old_lock['inputs'][key]
        need(fp(dependency.read_bytes()) == {'bytes': expected['bytes'], 'sha256': expected['sha256']},
             'Old source dependency differs: ' + key)
        command += ['--' + option, str(dependency)]
    command += ['--work-dir', str(work / 'baseline-source-build')]
    run('01-doc3-from-complete-source-chain', command, old)
    baseline = work / 'baseline-source-build/integration/output' / lock['baseline']['filename']
    need(fp(baseline.read_bytes()) == {k: lock['baseline'][k] for k in ('bytes', 'sha256')},
         'Source-built doc3 baseline differs')

    native_source = work / 'components/native-rc5'
    run('02-three-platform-rc5-from-source', [sys.executable, '-B', 'build.py'], native_source)
    native_dist = native_source / 'dist/0.1.0-rc.5'
    grok_source = work / 'components/grok-adapter'
    grok_output = work / 'grok-generated'
    run('03-grok-adapter-from-source',
        [sys.executable, '-B', 'build.py', '--output', str(grok_output)], grok_source)
    grok_archive = grok_output / lock['grok_archive']['filename']
    need(fp(grok_archive.read_bytes()) == {k: lock['grok_archive'][k] for k in ('bytes', 'sha256')},
         'Source-built Grok adapter differs')

    assembly = work / 'assembly'
    assembly_lock = json.loads((assembly / 'input-lock.json').read_text('utf-8'))
    platforms = assembly / 'platforms'
    platforms.mkdir()
    for key, spec in assembly_lock['platforms'].items():
        if key == 'grok':
            outer = [a for a in spec['archives'] if a.get('kind', 'full_expanded') == 'full_expanded']
            need(len(outer) == 1, 'Expected one Grok outer expanded archive contract')
            contract = outer[0]
            with zipfile.ZipFile(grok_archive) as archive:
                need(archive.testzip() is None, 'Generated Grok ZIP CRC differs')
                expanded = {contract['expanded_prefix'] + n[len(contract['archive_prefix']):]: archive.read(n)
                            for n in archive.namelist() if n.startswith(contract['archive_prefix'])}
                need(len(expanded) == len(archive.namelist()), 'Unexpected Grok archive prefix')
            generated = {**expanded, contract['path']: grok_archive.read_bytes()}
        else:
            generated = {name: (native_dist / name).read_bytes() for name in spec['files']}
        need(set(generated) == set(spec['files']), 'Generated platform inventory differs: ' + key)
        for name, expected in spec['files'].items():
            data = generated[name]
            need(fp(data) == expected, 'Generated platform bytes differ: ' + name)
            target = platforms / name
            need(platforms in target.resolve().parents, 'Generated platform path escapes')
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    # The builder must write inside its copied assembly directory, as its own contract requires.
    run('04-final-combination', [sys.executable, '-B', 'build_incremental.py',
        '--lock', str(assembly / 'input-lock.json'), '--baseline', str(baseline),
        '--platforms', str(platforms), '--documents', str(assembly / 'documents'),
        '--output', str(assembly / 'output')], assembly)
    product = assembly / 'output' / lock['final']['artifact']
    identity = fp(product.read_bytes())
    need(identity == {k: lock['final'][k] for k in ('bytes', 'sha256')}, 'Final product differs from locked target')
    with zipfile.ZipFile(product) as archive:
        need(archive.testzip() is None and len(archive.namelist()) == lock['final']['members'],
             'Final product CRC or member count differs')
    need(source_check() == before, 'Original source changed during rebuild')
    record.update(result='pass', finished_utc=datetime.now(timezone.utc).isoformat(),
                  product=str(product.relative_to(work)), **identity,
                  members=lock['final']['members'], original_source_files_unchanged=len(before),
                  source_built_doc3_identity=fp(baseline.read_bytes()),
                  generated_grok_adapter_identity=fp(grok_archive.read_bytes()),
                  native_or_browser_tests=False, publication=False)
    (work / 'run-record.json').write_bytes(encoded(record))
    print(json.dumps(record, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
