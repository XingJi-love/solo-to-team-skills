# 版本和范围 / Version and scope

这是《一人成阵》组合包的发布候选。核心首单包使用 RC.4.2 收存字节，旧统一建队台和其 source/ 源码保留 0.2.2b；日常配置使用 team-16/ 中的16席建队台，当前组件源码入口见 SOURCE.md，旧 builder/ 与 core/ 建队器保留原版核对，续办核验器使用 v1.3。实际组合版本与每项文件指纹见 `checksums.json`。示例使用合成业务；真实产品展示案例中的退修与交回依团队本机观察、云端审核与收件记录。[续办工具单独下载](downloads/handoff-checker-1.3a.zip)供核原始包指纹。只有各项明示的实证属于相应范围。所列项目自制材料采用 [MIT](LICENSE)，允许商用；范围与例外见 [NOTICE](NOTICE)。

[原有四项技能和许可](core/skills-original/README.md) · [原技能 LICENSE](core/skills-original/LICENSE) · [NOTICE](core/skills-original/NOTICE) · [源码来源](source/SOURCES.md)

This is a release candidate. The core exercise is RC.4.2; the historical unified builder and its source/ directory retain version 0.2.2b. The handoff checker is v1.3. The builder inside the frozen core belongs to RC.4.2. Use team-16/ for current exports; SOURCE.md identifies the current component sources. The old builder/ is retained for historical comparison. The demonstration media came from an internally reviewed product presentation. The standalone handoff ZIP is included under downloads for separate sharing and comparison of its original archive hash. The original four skills keep their existing license and notice; the listed project-authored materials use [MIT](LICENSE), including commercial use, within the scope and exclusions in [NOTICE](NOTICE).


## 组件与入口 / Components and entry points

| 交付层 / Layer | 版本 / Version | 用途 / Use |
|---|---|---|
| [旗舰入口 / Flagship](index.html) | 0.3.0-rc.15 | 本包起点 / Start here |
| [原核心 / Frozen core](core/index.html) · [中文](core/README.md) · [English](core/README.en.md) | 0.1.0-rc.4.2 | 早期 core/team-builder 留供核对 / Historical builder retained |
| [历史建队台 / Historical builder](builder/四端统一建队台.html) | 0.2.2b | 保留原版，不是当前16席入口 / Original bytes, not the current 16-role entry |
| [历史源码 / Historical source](source/README.md) | 0.2.2b | 仅重建旧统一台；当前见 SOURCE.md / Rebuilds the old builder only; current sources are in SOURCE.md |
| [续办工具 / Resume](resume/从这里续办.html) · [English](resume/从这里续办.html#en) | 1.3 (doc revision a) | 断点格式为 v1 / Checkpoint format v1 |


组件的原 ZIP 指纹见 components；解压后可复算 component_trees。逐文件 SHA-256、两个空格、组件内相对路径和换行，按路径 UTF-8 字节升序拼接后再求 SHA-256。

Upstream archive fingerprints are listed under components. The component_trees values hash UTF-8 lines sorted by relative path bytes, each with file SHA-256, two spaces, the path within its component and LF.

## 新增组件 / Added components

| Component | Version | Scope |
| --- | --- | --- |
| [16 席团队 / 16-role team](team-16/index.html) | 0.3.0-rc.15 | 16 岗、6 群、26 条建议群籍；按宿主实际能力启用 / 16 roles, six groups and 26 suggested memberships; activation depends on the host |
| [带底稿 / Start with files](start-with-files/index.html) | 0.3.0-rc.15 | 文件选择、原件清单及原生 DSH 项目 / File selection and a native DSH workspace |
| [配置更新 / Update my team](update-team/index.html) | 0.3.0-rc.15 | 三方对照与新配置下载 / Three-way comparison and a new configuration |
| [首次使用 / First two checks](learn/first2.html) | 0.3.0-rc.15 | 首次使用讲解，含合成题与退修示例 / First-use walkthrough with a fictional exercise and review examples |
| [陶艺印样 / Pottery print proof](proof/pottery/README.md) | v1 | 虚构输入、实际产物 / Fictional inputs and actual artifacts |

带底稿开工在本机准备文件，采用宿主后才会调用模型。陶艺展签为虚构业务样本，本机操作者记录了原生宿主中的制作、独立审核和原会话交回。异机复核覆盖所收到的文件与页面。旧四项技能的许可见其原件；新增项目自制材料的 MIT 范围见 NOTICE。

Preparing a workspace with your own files runs locally. The chosen host handles model use after setup. For the fictional pottery order, the Mac operator recorded production, independent review and return in the native host. Cross-machine review covered the received files and pages. NOTICE defines the MIT scope for the added project-authored materials.
