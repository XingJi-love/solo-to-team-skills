# 完整MAS＋四平台专用Skill候选

完整16席、6群、26条建议群籍、建队台、核心规则v2与原四款Skill保留。新增四平台专用Skill是加法；本组合为整合候选，尚未正式发布，没有统一一键全部安装或自动建队承诺。

WorkBuddy和DeepSeek为0.1.0-rc.5，OpenMaus为0.1.0-rc.5-om.4；Grok为grok-task-materials-design-2-doc-1（包装adapter.5），发布版本未定。

解压主包后，从本页选择平台。已有可用账号与模型继续沿用；本包不购买额度、创建账号或扩大权限。

| 平台 | 当前身份 | 文件与说明 | 有限核收范围 |
|---|---|---|---|
| WorkBuddy | 0.1.0-rc.5 | [文件](skills-add-on/workbuddy/solo-to-team-workbuddy.zip) · [说明](skills-add-on/workbuddy/开始使用.md)；首次可按说明上传单技能ZIP；同名更新沿用现有规则。 | 本机5.9.3保存及一份规则样本，保留首稿与局部纠正稿。 |
| OpenMausBot | 0.1.0-rc.5-om.4 | [文件](skills-add-on/openmaus/solo-to-team-openmaus-0.1.0-rc.5-om.4-candidate.zip) · [说明](skills-add-on/openmaus/开始使用.md)；解压后向目标Bot提供主文与三份参考，按原生学习保存采用。 | 四份正文保存核同，新会话读取通则及运营署；不是六群运行。 |
| DeepSeek Harness | 0.1.0-rc.5 | [文件](skills-add-on/deepseek/solo-to-team-deepseek-project.zip) · [说明](skills-add-on/deepseek/开始使用.md)；先核真实项目根与同名旧件，再放入本项目.dsh/skills。 | 项目级新版本与一份有限规则样本；不推定全局安装或多席业务。 |
| Grok Bot | design2-doc1 / adapter.5 | [文件](skills-add-on/grok/MAS-Grok-design2-doc1-adapter.5-local-candidate.zip) · [说明](skills-add-on/grok/开始使用.md)；先解压包装，再提供其中“仅上传”ZIP；正文与任务资料分开保存，按说明核对。 | 旧design2正文与五份资料回件核同，有限任务及人工双Bot审阅已核；本版doc1保存读回正文已逐字核同、旧头部保留，一次按名调用为测试Bot自报，新资料清单回件已逐字核同；旧业务证据不移作本版重跑通过。实际Skill/Read调用仍仅自报；原始提交参数、调用全文与同Bot新会话接续未独立验证，不能据此承诺自动加载或完整通过。详见采用说明。 |

同版且已核可用就复用；不同版按已有适用替换依据保留旧件后处理。技能保存不等于建立团队，不覆盖现役职责或权限。Grok具体新会话步骤待真实结果，不编统一按钮。

## 保留入口

- [原MAS工作台](index.html)
- [16席六群建队台](team-16/index.html)
- [带底稿开始](start-with-files/index.html)
- [更新已有团队](update-team/index.html)
- [原四款Skill](core/skills-original/README.md)
- [当前版本与证据范围](skills-add-on/当前版本与入口.md)
- [新增技能文件清单](skills-add-on/manifest.json)
- [组合文件清单](combined-checksums.json)
- [许可与例外](NOTICE)

## 证据边界

旧design2正文与五份资料回件核同，有限任务及人工双Bot审阅已核；本版doc1保存读回正文已逐字核同、旧头部保留，一次按名调用为测试Bot自报，新资料清单回件已逐字核同；旧业务证据不移作本版重跑通过。实际Skill/Read调用仍仅自报；原始提交参数、调用全文与同Bot新会话接续未独立验证，不能据此承诺自动加载或完整通过。详见采用说明。

建队台已有本人默认导出、改名保存重开、键盘换岗、减岗和恢复的有限链，沿用相同制品证据。三端规则样本、原有三/四席业务与全部16席联动不同，不混记通过。冻结底座SOURCE仍描述原组件源；本候选新增平台来源另见组合锁与维护说明，不把原底座源说成能独立生成本轮四端修订。

本次吸收朋友反馈并补齐同名更新分支；Grok doc1保存读回正文已逐字核同，一次按名调用为测试Bot自报，新资料清单回件已逐字核同。旧design2业务实测仍按原范围保留，其他三端载荷原字节不变。
